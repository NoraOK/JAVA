public class PythagoreanTest{
    public static void main(String[] args){
    Pythagorean iD = new Pythagorean();
        String hypot = iD.calculateHypotenuse(3, 4);
        System.out.println(hypot);
    }
}