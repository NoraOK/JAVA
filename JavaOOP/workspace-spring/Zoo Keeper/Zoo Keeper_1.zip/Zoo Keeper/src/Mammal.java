
public class Mammal {
	protected int energylevel = 100;
	
	public Mammal(){
		displayEnergy();
	}
	
	public int displayEnergy() {
		System.out.println(energylevel);
		return energylevel;
	}
	
	
	

}
