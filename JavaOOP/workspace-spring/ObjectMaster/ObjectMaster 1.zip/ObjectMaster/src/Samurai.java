
public class Samurai extends Human{
	public Samurai() {
		
	}
}
