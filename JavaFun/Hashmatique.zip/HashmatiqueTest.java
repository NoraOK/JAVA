import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

public class HashmatiqueTest{
    public static void main(String[] args){
        Hashmatique iD = new Hashmatique();
        iD.hashmatique();
    }
}