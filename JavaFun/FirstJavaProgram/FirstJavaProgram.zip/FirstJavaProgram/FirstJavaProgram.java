public class FirstJavaProgram{
    public static void main(String args[]){
        System.out.println("My name is Nora O'Keeffe");
        System.out.println("I am 28 years old");
        System.out.println("My hometown is Pembroke, MA");

    }
}