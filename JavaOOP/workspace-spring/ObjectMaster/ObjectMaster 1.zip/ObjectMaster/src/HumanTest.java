
public class HumanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Wizard nora = new Wizard();
	    Samurai lauren = new Samurai();
	    Ninja lindsey = new Ninja();
	    
	    nora.attack(lindsey);
	    lindsey.displayStats();

	}

}
