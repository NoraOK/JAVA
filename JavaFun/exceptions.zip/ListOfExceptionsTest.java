import java.util.ArrayList;

public class ListOfExceptionsTest{
    public static void main(String[] args){
        ListOfExceptions iD = new ListOfExceptions();
        iD.listOfExceptions();
    }
}