
public class Ninja extends Human {
	public Ninja() {
		
	}
	
}
