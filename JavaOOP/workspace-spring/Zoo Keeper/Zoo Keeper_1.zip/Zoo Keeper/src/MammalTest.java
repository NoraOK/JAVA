
public class MammalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mammal nora = new Mammal();
		Gorilla lindsay = new Gorilla();
		lindsay.throwSomething();
		lindsay.displayEnergy();
		lindsay.climb();
		lindsay.displayEnergy();
		lindsay.eatBananas();
		lindsay.displayEnergy();
	}

}
