public class FizzBuzzTest{
    public static void main(String[] args){
        FizzBuzz iD = new FizzBuzz();
        String number = iD.fizzBuzz(9995);
        System.out.println(number);
    }
}