
public class Wizard extends Human{
	public Wizard() {
		
	}
}
