
public interface Ringable {
 
	public String ring();
//		return("Ring, ring, ring!");
	public String unlock(); 
//		return("Unlocking via");
}
